<?php
class Order_Model extends Base_Model
{
	protected $table = 'orders';
}
